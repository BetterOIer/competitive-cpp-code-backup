#include<iostream>
using namespace std;
const long long mod = 998244353;
const long long maxn = 1005;
inline long long read(){
	long long x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<1)+(x<<3)+(c^48);
	return x*f;
}
long long T,id,n,m,c,f;
bool G[maxn][maxn];
int dp[maxn][maxn];
long long ansC=0,ansF=0;
int dp2[maxn][maxn];
long long dfsC(long long i,long long j){
	if(G[i][j]==1||G[i+1][j]==1)return 0;
	long long ans2=dp[i][j]-1,ans1=0;
	if(ans2==0)return 0;
	i+=2;
	while(G[i][j]!=1&&i<=n){
		ans1+=1LL*(dp[i][j]-1)%mod;
		i++;
	}
	return ans1*ans2;
}
long long dfsF(long long i,long long j){
	if(G[i][j]==1||G[i+1][j]==1)return 0;
	long long ans2=dp[i][j]-1,ans1=0;
	if(ans2==0)return 0;
	i+=2;
	while(G[i][j]!=1&&i<=n){
		ans1+=1LL*(dp[i][j]-1)*(dp2[i][j]-1)%mod;
		i++;
	}
	return ans1*ans2;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(),id=read();
	while(T--){
		n=read(),m=read(),c=read(),f=read();
		ansC=ansF=0;
		c%=mod;f%=mod;
		bool flag1=(c==0),flag2=(f==0);
		string s;
		for(long long i = 1;i<=n;i++){
			cin>>s;
			for(long long j = 0;j<m;j++){
				G[i][j+1]=(s[j]=='1');
			}
		}
		//prework
		if(flag1==0||flag2==0)for(long long i = 1;i<=n;i++){
			for(long long j = m;j>=1;j--){
				if(G[i][j])dp[i][j]=0;
				else dp[i][j]=dp[i][j+1]+1;
			}
		}
		if(flag2==0)for(long long j = 1;j<=m;j++){
			for(long long i = n;i>=1;i--){
				if(G[i][j])dp2[i][j]=0;
				else dp2[i][j]=dp2[i+1][j]+1;
			}
		}
		//dealc
		if(flag1==0)for(long long i = 1;i<=n;i++){
			for(long long j = m;j>=1;j--){
				ansC=(ansC+dfsC(i,j)%mod)%mod;
			}
		}
		//dealf
		if(flag2==0)for(long long i = 1;i<=n;i++){
			for(long long j = m;j>=1;j--){
				ansF=(ansF+dfsF(i,j)%mod)%mod;
			}
		}
		ansC=ansC*c%mod;
		ansF=ansF*f%mod;
		cout<<ansC<<" "<<ansF<<endl;
		for(long long i = 1;i<=n;i++){
			for(long long j = 1;j<=n;j++){
				G[i][j]=0,dp[i][j]=0,dp2[i][j]=0;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
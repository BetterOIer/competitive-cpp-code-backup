#include<iostream>
uding namespace std;
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cout<<0;
} 

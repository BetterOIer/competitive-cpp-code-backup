#include<iostream>
#include<cmath>
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	return x*f;
}
int n,k;
long long dfs(int now,int maxn){
    int tim=ceil(1.0*(now-(maxn>>1))/k);
    int tim2=ceil(1.0*now/k);
    if(tim==tim2)return 1;
    int left=now-k*tim;
    return ((dfs(left,left))<<1)+tim;
}
int main(){
    freopen("slime.in","r",stdin);
    freopen("slime.out","w",stdout);
    n=read(),k=read();
    cout<<dfs(n,n);
    fclose(stdin);
    fclose(stdout);
    return 0;
}